# Competitor Intelligence Report

Paste a competitor's URL. Get back a structured intelligence brief in ~2 minutes: who their customers are, what tech they run, how they position, and 3–5 specific gaps you can exploit. Neutral and factual — not a sales doc. Styled HTML output (print to PDF, screenshot for a deck). Pay-per-use. No API keys. MCP-compatible.

## What you get

One report per run, covering:

- **Executive Summary** — 2–3 paragraph overview of the competitor's strategy
- **Tech Stack** — CMS, hosting, analytics, marketing tools, and other detected technologies
- **Customers & Testimonials** — Named companies using the competitor's product, with direct quotes and metrics where available
- **Positioning & Value Proposition** — Key features, pricing model, and how they differentiate
- **Opportunities** — 3–5 specific gaps or weaknesses a competitor could exploit

## How it works

1. Crawls up to 5 pages of the competitor's site (prioritizing /customers, /case-studies, /testimonials, /about, /pricing, /blog)
2. Uses an LLM to analyze the content and generate a structured report
3. Returns the full report as plain text in the dataset

## Input

| Field | Description |
|-------|-------------|
| Competitor URL | The competitor's website (e.g., "https://stripe.com") |
| Industry | Optional: specify the industry for better context |
| Max Pages | Number of pages to crawl (default: 5) |
| LLM Model | Gemini 2.5 Flash or Claude Haiku 4.5 |

## Output

One row in the dataset:

| Field | Description |
|-------|-------------|
| competitor_url | The URL you analyzed |
| pages_crawled | How many pages were successfully fetched |
| report | The full intelligence report (plain text) |

## Use cases

- **Before a sales call** — Know who your prospect's current vendor is, what they're paying, and where the gaps are
- **Track competitor customer wins** — See which companies are publicly associated with a competitor
- **Find switching candidates** — Identify customers with quoted pain points or dissatisfaction
- **Pricing intelligence** — Understand how a competitor positions their pricing (or hides it)
- **Content strategy** — Find positioning language and features you should counter

## Pricing

Pay-per-event: $5 per completed report.

## Notes

- No API keys required — LLM calls are handled via Apify's built-in OpenRouter proxy.
- Average run time: 30–90 seconds.
- Sites that block scraping (Cloudflare, bot detection) may return fewer pages. The report will reflect only what was successfully crawled.
- Tech stack detection is based on visible signals in page content (scripts, meta tags, mentions). For deeper fingerprinting, pair with a dedicated tool like BuiltWith.


## MCP

Add this to your MCP client config to use this actor as a tool:

```json
{
  "mcpServers": {
    "apify": {
      "url": "https://mcp.apify.com/?tools=harmony_labs/competitor-intel-report"
    }
  }
}   

```

## Related

[Head-to-Head Competitor Analysis](https://apify.com/harmony_labs/head-to-head) — two competitor URLs in, a neutral 7-section comparative brief out (positioning, pricing, feature gaps) in under 3 minutes.   
- [AI Keyword Generator](https://apify.com/harmony_labs/ai-keyword-generator) — one seed keyword in, a ranked list of long-tail keywords out with search intent and difficulty scores.