import os
import re
import asyncio
import logging
import httpx
from apify import Actor
from openai import AsyncOpenAI

OPENROUTER_BASE_URL = "https://openrouter.apify.actor/api/v1"

PRIORITY_PATHS = [
    "/pricing", "/features", "/customers", "/case-studies",
    "/testimonials", "/about", "/solutions", "/product"
]

USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"


def strip_html(html):
    html = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL)
    html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.DOTALL)
    html = re.sub(r'<nav[^>]*>.*?</nav>', '', html, flags=re.DOTALL)
    html = re.sub(r'<footer[^>]*>.*?</footer>', '', html, flags=re.DOTALL)
    html = re.sub(r'<header[^>]*>.*?</header>', '', html, flags=re.DOTALL)
    html = re.sub(r'<aside[^>]*>.*?</aside>', '', html, flags=re.DOTALL)
    html = re.sub(r'<[^>]+>', '\n', html)
    html = re.sub(r'\n\s*\n', '\n', html)
    return html.strip()


async def crawl_site(base_url, max_pages):
    base_url = base_url.rstrip("/")
    if not base_url.startswith("http"):
        base_url = f"https://{base_url}"

    urls_to_try = [base_url]
    for path in PRIORITY_PATHS:
        urls_to_try.append(f"{base_url}{path}")

    urls_to_try = urls_to_try[:max_pages]

    all_content = []
    client = httpx.AsyncClient(
        follow_redirects=True,
        timeout=15,
        headers={"User-Agent": USER_AGENT}
    )

    for url in urls_to_try:
        try:
            resp = await client.get(url)
            if resp.status_code == 200:
                text = strip_html(resp.text)
                if len(text) > 8000:
                    text = text[:8000] + "\n[... truncated ...]"
                all_content.append(f"### Page: {url}\n{text}")
            else:
                logging.getLogger().info(f"  SKIP {url} (status {resp.status_code})")
        except Exception:
            logging.getLogger().info(f"  SKIP {url} (request failed)")

    await client.aclose()

    pages_fetched = len(all_content)
    content = "\n\n".join(all_content) if all_content else ""
    return content, pages_fetched


def build_prompt(competitor_url, content, industry):
    domain = competitor_url.replace("https://", "").replace("http://", "").rstrip("/")

    if not content:
        return f"""You are a competitive intelligence analyst. A user requested a report on {domain}, but the website blocked automated access. No content could be fetched.

Write a short, plain-text message (3-4 sentences) that:
1. States that the report could not be completed because the site blocks automated access
2. Suggests the user try again later
3. Mentions that sites behind Cloudflare or similar bot protection are the most common cause

Do not invent any information about this company."""

    return f"""You are a competitive intelligence analyst. Analyze the following website content and produce a structured competitive intelligence report.

## Website: {competitor_url}
{content}

## Industry Context: {industry or "Not specified"}

Produce a report with these exact sections:

## Executive Summary
2-3 paragraph overview of the competitor's strategy, positioning, and market presence.

## Tech Stack
CMS, hosting, analytics, marketing tools, and other detected technologies.

## Customers & Testimonials
Named companies using the competitor's product, with direct quotes and metrics where available.

## Positioning & Value Proposition
Key features, pricing model, and how they differentiate from competitors.

## Opportunities
3-5 specific gaps or weaknesses a competitor could exploit. Be specific — reference actual pages, features, or messaging from the crawled content.

Rules:
- Be specific. Quote actual language from the pages where relevant.
- Do not speculate beyond what the crawled content supports.
- Write in plain text, no markdown formatting."""


def text_to_html(report_text, competitor_url, pages_crawled, industry):
    domain = competitor_url.replace("https://", "").replace("http://", "").rstrip("/")

    report_text = re.sub(r'^[=\-*_]{3,}\s*$', '', report_text, flags=re.MULTILINE)   

    sections = re.split(r'(?=^## )', report_text, flags=re.MULTILINE)
    body_html = ""

    for section in sections:
        section = section.strip()
        if not section:
            continue
        if section.startswith("## "):
            title = section[3:].strip()
            rest = section[3:].split("\n", 1)
            content = rest[1].strip() if len(rest) > 1 else ""
            body_html += f'<section><h2>{title}</h2><div class="content">{content.replace(chr(10), "<br>")}</div></section>\n'
        else:
            body_html += f'<div class="content">{section.replace(chr(10), "<br>")}</div>\n'

    industry_tag = f'<span class="tag">{industry}</span>' if industry else ""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Competitor Intelligence Report — {domain}</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    color: #1a1a2e;
    background: #f8f9fc;
    line-height: 1.7;
    padding: 40px 20px;
  }}
  .container {{
    max-width: 780px;
    margin: 0 auto;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 20px rgba(0,0,0,0.06);
    padding: 48px;
  }}
  .header {{
    border-bottom: 2px solid #e8eaf0;
    padding-bottom: 24px;
    margin-bottom: 32px;
  }}
  .header h1 {{
    font-size: 28px;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 8px;
  }}
  .header .meta {{
    font-size: 14px;
    color: #6b7280;
    display: flex;
    gap: 16px;
    align-items: center;
    flex-wrap: wrap;
  }}
  .tag {{
    background: #eef2ff;
    color: #4338ca;
    padding: 2px 10px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
  }}
  section {{
    margin-bottom: 28px;
  }}
  section h2 {{
    font-size: 18px;
    font-weight: 600;
    color: #1a1a2e;
    margin-bottom: 12px;
    padding-bottom: 6px;
    border-bottom: 1px solid #e8eaf0;
  }}
  .content {{
    font-size: 15px;
    color: #374151;
  }}
  .footer {{
    margin-top: 40px;
    padding-top: 20px;
    border-top: 1px solid #e8eaf0;
    font-size: 12px;
    color: #9ca3af;
    text-align: center;
  }}
  @media (max-width: 600px) {{
    .container {{ padding: 24px; }}
    .header h1 {{ font-size: 22px; }}
  }}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>Competitor Intelligence Report</h1>
    <div class="meta">
      <span>{domain}</span>
      <span>{pages_crawled} pages analyzed</span>
      {industry_tag}
    </div>
  </div>
  {body_html}
  <div class="footer">
    Generated by <a href="https://apify.com/harmony_labs/competitor-intel-report" style="color:#4338ca;">Competitor Intelligence Report</a> on Apify
  </div>
</div>
</body>
</html>"""


async def main():
    async with Actor:
        input_data = await Actor.get_input()

        competitor_url = input_data["competitorUrl"]
        industry = input_data.get("industry", "")
        max_pages = input_data.get("maxPages", 5)
        model = input_data.get("model", "anthropic/claude-haiku-4.5")

        log = logging.getLogger()
        log.info(f"Crawling {competitor_url} (max {max_pages} pages)")

        content, pages_fetched = await crawl_site(competitor_url, max_pages)

        log.info(f"Got {pages_fetched} pages")

        if pages_fetched == 0:
            report = f"Report could not be completed. {competitor_url} blocked automated access. No pages could be fetched. This is typically caused by Cloudflare or similar bot protection. Please try again later."
        else:
            client = AsyncOpenAI(
                base_url=OPENROUTER_BASE_URL,
                api_key=os.environ["APIFY_TOKEN"],
            )

            prompt = build_prompt(competitor_url, content, industry)

            response = await client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": "You are a competitive intelligence analyst. You produce structured, specific, actionable reports. You never speculate beyond the provided content."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=4000,
                temperature=0.3,
            )

            report = response.choices[0].message.content

        await Actor.push_data({
            "competitor_url": competitor_url,
            "pages_crawled": pages_fetched,
            "report": report,
        })

        html = text_to_html(report, competitor_url, pages_fetched, industry)
        await Actor.set_value("report.html", html, content_type="text/html")

        await Actor.charge(event_name="report-complete")

        log.info("Done. Report pushed to dataset and HTML saved to KV store.")


if __name__ == "__main__":
    asyncio.run(main())