# Head-to-Head Competitor Analysis

Paste your URL and a competitor's URL. Get back a structured 7-section comparative intelligence brief in 1–3 minutes: positioning, pricing, feature gaps, messaging, tech stack, and the 3–5 most important differences. Neutral and factual — not a sales doc. Styled HTML output (print to PDF, screenshot for a deck). $5 per report. No API keys. MCP-compatible.


## What you get

One competitive analysis report per run.
One neutral, factual comparison report per run (not a sales doc, not two separate analyses). Covers:   

- Overview — what each company does, who they serve, where they overlap
- Positioning — value props, target audience, key differentiators, side by side
- Pricing — tiers, entry price, free tier, billing model, and what each signals
- Feature & Capability Comparison — what each offers that the other doesn't, named specifically
- Messaging & Tone — CTAs, social proof, brand voice, and what the differences imply
- Tech Stack — CMS, hosting, analytics, marketing tools detected on each site
- Key Differences — the 3-5 most important differences, factual and unranked
- Styled HTML output — open it in a browser, print to PDF, or screenshot for a deck   

## How it works

1. Crawls up to N pages of each website (prioritizing /about, /team, /portfolio, /pricing, /features, /customers, /case-studies, /insights, /research, /blog)   
2. Sends both content sets to an LLM for comparative analysis
3. 3. Returns the full report as plain text in the dataset, plus a styled HTML report in the key-value store   

## Input

| Field | Description |
|---|---|
| Your Website | Your company's website URL |
| Competitor Website | The competitor's website URL |
| Industry | Optional context for the analysis |
| Max Pages (per site) | Pages to crawl on each site (default: 10) |
| LLM Model | Gemini 2.5 Flash or Claude Haiku 4.5 |

## Output

One row in the dataset:

| Field | Description |
|---|---|
| my_url | Your website URL |
| competitor_url | Competitor's website URL |
| report | Full comparative report (styled HTML & plain text) |

## Use cases

- Competitive analysis — understand where you and a competitor differ
- Product strategy — find feature gaps and positioning differences
- Sales preparation — know how a competitor frames their offering before a call
- Due diligence — compare positioning, pricing, and features before a meeting or investment decision
- Board/investor updates — quarterly competitive landscape comparison
- Market research — understand how two players in the same space differentiate
- Weekly competitor monitoring — schedule a run per competitor and track how the comparison shifts over time   

## Pricing

Pay-per-event: $10 per completed comparison report.

## Notes

- No API keys required — LLM calls via Apify's OpenRouter proxy
- Average run time: 1-3 minutes (two sites + competitive analysis)
- Sites that block scraping (Cloudflare, bot detection) may return fewer pages. The report reflects only what was successfully crawled.
- Tech stack detection is based on visible signals in page content (scripts, meta tags, mentions). For deeper fingerprinting, pair with a dedicated tool like BuiltWith.

## MCP

Add this to your MCP client config to use this actor as a tool:

```json
{
  "mcpServers": {
    "apify": {
      "url": "https://mcp.apify.com/?tools=harmony_labs/head-to-head-competitor-analysis"
    }
  }
}

```

## Related

- [Competitor Intelligence Report](https://apify.com/harmony_labs/competitor-intel-report) — single-site deep dive (tech stack, customers, positioning)
- [AI Keyword Generator](https://apify.com/harmony_labs/ai-keyword-generator) — seed keyword in, ranked long-tail keywords out