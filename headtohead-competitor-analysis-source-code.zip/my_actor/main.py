import os
import re
import asyncio
import logging
import httpx   
import html as html_escape   
from apify import Actor
from openai import AsyncOpenAI

OPENROUTER_BASE_URL = "https://openrouter.apify.actor/api/v1"

PRIORITY_PATHS = [
    "/about", "/team", "/portfolio", "/insights", "/research",
    "/pricing", "/features", "/customers", "/case-studies",
    "/testimonials", "/solutions", "/product", "/blog"
]   

USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"


def extract_domain(url):
    return url.replace("https://", "").replace("http://", "").rstrip("/")


def strip_html(html):
    html = re.sub(r'<script[^>]*>.*?</script>', '', html, flags=re.DOTALL)
    html = re.sub(r'<style[^>]*>.*?</style>', '', html, flags=re.DOTALL)
    html = re.sub(r'<nav[^>]*>.*?</nav>', '', html, flags=re.DOTALL)
    html = re.sub(r'<footer[^>]*>.*?</footer>', '', html, flags=re.DOTALL)
    html = re.sub(r'<header[^>]*>.*?</header>', '', html, flags=re.DOTALL)
    html = re.sub(r'<aside[^>]*>.*?</aside>', '', html, flags=re.DOTALL)
    html = re.sub(r'<[^>]+>', '\n', html)
    html = re.sub(r'\n\s*\n', '\n', html)
    return html.strip()


async def crawl_site(base_url, max_pages):
    base_url = base_url.rstrip("/")
    if not base_url.startswith("http"):
        base_url = f"https://{base_url}"

    urls_to_try = [base_url]
    for path in PRIORITY_PATHS:
        urls_to_try.append(f"{base_url}{path}")

    urls_to_try = urls_to_try[:max_pages]

    all_content = []
    client = httpx.AsyncClient(
        follow_redirects=True,
        timeout=15,
        headers={"User-Agent": USER_AGENT}
    )

    for url in urls_to_try:
        try:
            resp = await client.get(url)
            if resp.status_code == 200:
                text = strip_html(resp.text)
                if len(text) > 8000:
                    text = text[:8000] + "\n[... truncated ...]"
                all_content.append(f"### Page: {url}\n{text}")
            else:
                logging.getLogger().info(f"  SKIP {url} (status {resp.status_code})")
        except Exception:
            logging.getLogger().info(f"  SKIP {url} (request failed)")

    await client.aclose()

    pages_fetched = len(all_content)
    content = "\n\n".join(all_content) if all_content else ""
    return content, pages_fetched


def build_prompt(my_url, competitor_url, my_content, competitor_content, industry):
    name_a = extract_domain(my_url)
    name_b = extract_domain(competitor_url)

    if not my_content and not competitor_content:
        return f"""You are a competitive intelligence analyst. A user requested a comparison between {name_a} and {name_b}, but both websites blocked automated access. No content could be fetched from either site.

Write a short, plain-text message (3-4 sentences) that:
1. States that the comparison could not be completed because both sites block automated access
2. Suggests the user try again later or use a different pair of sites
3. Mentions that sites behind Cloudflare or similar bot protection are the most common cause

Do not invent any information about these companies."""

    if not my_content:
        note_a = f"[NOTE: {name_a} blocked automated access. No content was fetched from this site. Analyze only {name_b} and note that {name_a} could not be crawled.]"
        note_b = ""
    elif not competitor_content:
        note_a = ""
        note_b = f"[NOTE: {name_b} blocked automated access. No content was fetched from this site. Analyze only {name_a} and note that {name_b} could not be crawled.]"
    else:
        note_a = ""
        note_b = ""

    return f"""You are a competitive intelligence analyst. You are writing ONE comparative analysis of two companies — not two separate reports, not a sales document. Your job is to lay out the differences clearly and factually so the reader can form their own conclusions.

## {name_a}
{my_content if my_content else "[Site blocked automated access — no content available]"}
{note_a}

## {name_b}
{competitor_content if competitor_content else "[Site blocked automated access — no content available]"}
{note_b}

## Industry Context: {industry or "Not specified"}

Produce a single report with these sections:

## Overview
2-3 paragraphs. What each company does, who they serve, and where they overlap. Set the stage for the comparison. If one site was inaccessible, note that clearly and base your analysis on the available content only.

## Positioning
How each company frames the problem and their solution. Target audience, core value proposition, key differentiators. Side-by-side where possible. Quote their actual language.

## Pricing
Tiers, entry price, free tier availability, billing model for each. Where one is cheaper, where the other is, and what that signals about their strategy. Note if either hides pricing.

## Feature & Capability Comparison
What {name_a} offers that {name_b} doesn't. What {name_b} offers that {name_a} doesn't. Name the specific features. Be factual, not promotional.

## Messaging & Tone
CTA strategy, social proof approach (logos, numbers, testimonials), brand voice. Where the tones diverge and what that implies about each company's target audience.

## Tech Stack
CMS, hosting, analytics, marketing tools detected on each site. Note any significant differences.

## Key Differences
A concise summary of the 3-5 most important differences between the two companies based on what was crawled. Not ranked, not opinionated — just the differences that matter most.

Rules:
- This is ONE comparative analysis, not two reports side by side
- Stay neutral and factual. Do not take a side. Do not say "you should do X."
- Use the company names ({name_a} and {name_b}) throughout
- Quote actual language from the pages where relevant
- Do not speculate beyond what the crawled content supports
- If a site was inaccessible, say so explicitly in the report. Do not fill in gaps with guesses.
- Write in plain text, no markdown formatting"""


def text_to_html(report_text, my_url, competitor_url, pages_a, pages_b, industry):
    name_a = extract_domain(my_url)
    name_b = extract_domain(competitor_url)

    report_text = re.sub(r'^[=\-*_]{3,}\s*$', '', report_text, flags=re.MULTILINE)

    sections = re.split(r'(?=^## )', report_text, flags=re.MULTILINE)
    body_html = ""

    for section in sections:
        section = section.strip()
        if not section:
            continue
        if section.startswith("## "):
            title = section[3:].strip()
            rest = section[3:].split("\n", 1)
            content = rest[1].strip() if len(rest) > 1 else ""
            body_html += f'<section><h2>{title}</h2><div class="content">{html_escape.escape(content).replace(chr(10), "<br>")}</div></section>\n'
        else:
            body_html += f'<div class="content">{section.replace(chr(10), "<br>")}</div>\n'

    industry_tag = f'<span class="tag">{industry}</span>' if industry else ""

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Head-to-Head Competitor Analysis — {name_a} vs {name_b}</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    color: #1a1a2e;
    background: #f8f9fc;
    line-height: 1.7;
    padding: 40px 20px;
  }}
  .container {{
    max-width: 780px;
    margin: 0 auto;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 20px rgba(0,0,0,0.06);
    padding: 48px;
  }}
  .header {{
    border-bottom: 2px solid #e8eaf0;
    padding-bottom: 24px;
    margin-bottom: 32px;
  }}
  .header h1 {{
    font-size: 28px;
    font-weight: 700;
    color: #1a1a2e;
    margin-bottom: 8px;
  }}
  .header .vs {{
    display: flex;
    align-items: center;
    gap: 12px;
    margin-top: 12px;
  }}
  .header .vs .site {{
    font-size: 16px;
    font-weight: 600;
    color: #374151;
    background: #eef2ff;
    padding: 4px 12px;
    border-radius: 6px;
  }}
  .header .vs .vs-label {{
    font-size: 13px;
    font-weight: 700;
    color: #9ca3af;
    text-transform: uppercase;
  }}
  .header .meta {{
    font-size: 14px;
    color: #6b7280;
    display: flex;
    gap: 16px;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 12px;
  }}
  .tag {{
    background: #eef2ff;
    color: #4338ca;
    padding: 2px 10px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
  }}
  section {{
    margin-bottom: 28px;
  }}
  section h2 {{
    font-size: 18px;
    font-weight: 600;
    color: #1a1a2e;
    margin-bottom: 12px;
    padding-bottom: 6px;
    border-bottom: 1px solid #e8eaf0;
  }}
  .content {{
    font-size: 15px;
    color: #374151;
  }}
  .footer {{
    margin-top: 40px;
    padding-top: 20px;
    border-top: 1px solid #e8eaf0;
    font-size: 12px;
    color: #9ca3af;
    text-align: center;
  }}
  @media (max-width: 600px) {{
    .container {{ padding: 24px; }}
    .header h1 {{ font-size: 22px; }}
    .header .vs {{ flex-direction: column; gap: 8px; }}
  }}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <h1>Head-to-Head Competitor Analysis</h1>   
    <div class="vs">
      <span class="site">{name_a}</span>
      <span class="vs-label">vs</span>
      <span class="site">{name_b}</span>
    </div>
    <div class="meta">
      <span>{pages_a} pages from {name_a}</span>
      <span>{pages_b} pages from {name_b}</span>
      {industry_tag}
    </div>
  </div>
  {body_html}
  <div class="footer">
    Generated by <a href="https://apify.com/harmony_labs/head-to-head-competitor-analysis" style="color:#4338ca;">Head-to-Head Competitor Analysis</a> on Apify
  </div>
</div>
</body>
</html>"""


async def main():
    async with Actor:
        input_data = await Actor.get_input()

        my_url = input_data["myUrl"]
        competitor_url = input_data["competitorUrl"]
        industry = input_data.get("industry", "")
        max_pages = input_data.get("maxPagesPerSite", 10)
        model = input_data.get("model", "anthropic/claude-haiku-4.5")

        log = logging.getLogger()
        log.info(f"Crawling {my_url} and {competitor_url} (max {max_pages} pages each)")

        (my_content, my_pages), (comp_content, comp_pages) = await asyncio.gather(
            crawl_site(my_url, max_pages),
            crawl_site(competitor_url, max_pages)
        )

        log.info(f"Site A: {my_pages} pages. Site B: {comp_pages} pages.")

        if my_pages == 0 and comp_pages == 0:
            report = f"Comparison could not be completed. Both {extract_domain(my_url)} and {extract_domain(competitor_url)} blocked automated access. No pages could be fetched from either site. This is typically caused by Cloudflare or similar bot protection. Please try again later or use a different pair of websites."
        else:
            client = AsyncOpenAI(
                base_url=OPENROUTER_BASE_URL,
                api_key=os.environ["APIFY_TOKEN"],
            )

            prompt = build_prompt(my_url, competitor_url, my_content, comp_content, industry)

            response = await client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": "You are a competitive intelligence analyst. You produce neutral, factual, structured comparisons. You do not take sides, give advice, or write sales documents. You never speculate beyond the provided content."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=4000,
                temperature=0.3,
            )

            report = response.choices[0].message.content

        await Actor.push_data({
            "my_url": my_url,
            "competitor_url": competitor_url,
            "report": report,
        })

        html = text_to_html(report, my_url, competitor_url, my_pages, comp_pages, industry)
        await Actor.set_value("report.html", html, content_type="text/html")

        await Actor.charge(event_name="comparison-complete")

        log.info("Done. Report pushed to dataset and HTML saved to KV store.")


if __name__ == "__main__":
    asyncio.run(main())