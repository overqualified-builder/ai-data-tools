# AI Keyword Generator

Generate long-tail SEO keywords with search intent and difficulty scores using AI.

## How it works

Give it a seed keyword. It returns a structured list of long-tail keywords, each labeled with:

- **keyword** — the long-tail phrase
- **intent** — informational, commercial, or transactional
- **estimated_difficulty** — 1–10

## Input

| Field | Description |
|-------|-------------|
| Seed Keyword | The main topic to expand (e.g., "sustainable running shoes") |
| Number of Keywords | How many to generate (default: 20) |
| LLM Model | Choose between Gemini 2.5 Flash or Claude Haiku 4.5 |

## Output

One row per keyword in the dataset:

```json
{
  "keyword": "best sustainable running shoes for flat feet",
  "intent": "commercial",
  "estimated_difficulty": 4
}
```

## MCP

Add this to your MCP client config to use this actor as a tool:

```json
{
  "mcpServers": {
    "apify": {
      "url": "https://mcp.apify.com/?tools=harmony_labs/ai-keyword-generator"
    }
  }
}   
```

## Related

[Head-to-Head Competitor Analysis](https://apify.com/harmony_labs/head-to-head) — two competitor URLs in, a neutral 7-section comparative brief out (positioning, pricing, feature gaps) in under 3 minutes.   
- [Competitor Intelligence Report](https://apify.com/harmony_labs/competitor-intel-report) — paste a competitor's URL, get their tech stack, customers, positioning, and exploitable gaps.