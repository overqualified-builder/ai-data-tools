from apify import Actor
import openai
import json
import os

async def main():
    async with Actor:
        actor_input = await Actor.get_input()
        seed_keyword = actor_input.get("seedKeyword")
        num_keywords = actor_input.get("numKeywords", 20)
        model = actor_input.get("model", "google/gemini-2.5-flash")

        client = openai.AsyncOpenAI(
            base_url="https://openrouter.apify.actor/api/v1",
            api_key=os.environ["APIFY_TOKEN"]
        )

        response = await client.chat.completions.create(
            model=model,
            response_format={"type": "json_object"},
            messages=[
                {
                    "role": "system",
                    "content": "You are an SEO keyword researcher. Return ONLY a valid JSON array. No markdown, no code fences, no explanation."
                },
                {
                    "role": "user",
                    "content": f"Generate {num_keywords} long-tail keywords related to: {seed_keyword}. Return as a JSON array of objects with fields: keyword (string), intent (string: informational/commercial/transactional), estimated_difficulty (integer 1-10)."
                }
            ],
            temperature=0.7
        )

        raw = response.choices[0].message.content.strip()
        if raw.startswith("```"):
            raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]

        keywords = json.loads(raw)

        for kw in keywords:
            await Actor.push_data(kw)

        await Actor.set_value("result", {"seed": seed_keyword, "count": len(keywords)})